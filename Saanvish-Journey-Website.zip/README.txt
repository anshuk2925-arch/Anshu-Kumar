# The Saanvish Journey

A responsive journal-style website for Anshu + Sadhvi.

## Files
- index.html — website structure and content
- style.css — visual design

## Run it
Open `index.html` in Chrome.

## Publish it
Upload both files to a static website host such as GitHub Pages or Netlify.
Make sure `index.html` and `style.css` are in the same folder.
